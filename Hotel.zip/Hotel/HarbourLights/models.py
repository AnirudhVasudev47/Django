from django.db import models
from django.contrib.auth.models import User

# Create your models here.

class Rooms(models.Model):
    
    room_type = models.CharField(max_length=150)
    img = models.ImageField(upload_to = 'pics' )
    price = models.FloatField()
    total_rooms = models.IntegerField()
    total_available = models.IntegerField()
    complimentary_brakefast = models.BooleanField()
    person_per_room = models.IntegerField()
    no_of_bed = models.IntegerField(default=2)

    class Meta:
        verbose_name_plural = "Room Details"



    def __str__(self):
        return self.room_type + ': ₹' +  str(self.price)

class Booking(models.Model):

    order_id = models.CharField(max_length = 30)
    user = models.ForeignKey(User, on_delete=models.DO_NOTHING)
    check_in = models.CharField(max_length = 20)
    check_out = models.CharField(max_length = 20)
    room_type = models.ForeignKey(Rooms , on_delete=models.DO_NOTHING)
    no_of_guest = models.IntegerField()
    TotalAmount = models.IntegerField()

    class Meta:
        verbose_name_plural = "Check-in Details"

    def __str__(self):
        return self.room_type.room_type + ': ' +  self.user.first_name   
