from django.apps import AppConfig


class HarbourlightsConfig(AppConfig):
    name = 'HarbourLights'
