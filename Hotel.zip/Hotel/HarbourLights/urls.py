from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name="index"),
    path('check', views.check, name='check'),
    path('book', views.book, name='book'),
    path('single_room/<id_no>/', views.single_room, name='single_room'),
    path('rooms', views.rooms, name="rooms")
]