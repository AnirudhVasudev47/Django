from django.shortcuts import render, redirect
from .models import Rooms, Booking
from django.contrib.auth.decorators import *
import math
from datetime import *

# Create your views here.
def index(request):
    obj = Rooms.objects.all()
    context = {'rooms' : obj}
    return render(request, 'index.html', context)

@login_required(login_url = '/accounts/login')
def book(request):
    user = request.POST['username']
    check_in = request.POST['check_in']
    check_out = request.POST['check_out']
    room_type = request.POST['room_type']
    no_of_guest = request.POST['no_of_guest']
    price = int(request.POST['total_price'])
    checkIn = datetime.strptime(check_in, '%m/%d/%Y') 
    checkOut = datetime.strptime(check_out, '%m/%d/%Y')
    total_days = checkOut - checkIn
    tot_price = price * total_days.days
    print(total_days.days)
    orderId = '#' + str(request.user.username) + str(price)
    book = Booking( order_id = orderId, check_in = check_in, check_out = check_out, room_type = Rooms.objects.get(room_type = room_type), no_of_guest = no_of_guest, TotalAmount = tot_price)
    book.user = request.user
    book.save()
    return render(request, 'room-booking.html')

def single_room(request, id_no):
    obj = Rooms.objects.get(id = int(id_no))
    context = {
        'id': obj.id,
        'room_img' : obj.img,
        'room_type' : obj.room_type,
        'price' : obj.price,
        'total_rooms' : obj.total_rooms,
        'total_available' : obj.total_available,
        'person_per_room' : obj.person_per_room,
        'no_of_bed' : obj.no_of_bed 
    }
    return render(request, 'rooms-single.html', context)

def rooms(request):

    obj = Rooms.objects.all()
    return render(request, 'rooms.html', {'rooms' : obj})

def check(request):
    if request.method == 'POST':
        room_type = request.POST['room_type']
        no_of_guest = int(request.POST['no_of_guest'])
        check_in = request.POST['check_in']
        check_out = request.POST['check_out']
        obj = Rooms.objects.get(room_type = room_type)
        available = int(obj.total_available)
        person_per_room = int(obj.person_per_room)
        chk =  math.ceil(no_of_guest/person_per_room)
        if available >= chk:
            tot_price = chk * int(obj.price)
            context = {
                'id': obj.id,
                'room_img' : obj.img,
                'room_type' : obj.room_type,
                'price' : tot_price,
                'total_rooms' : chk,
                'total_available' : obj.total_available,
                'person_per_room' : obj.person_per_room,
                'no_of_bed' : obj.no_of_bed,
                'check_in' : check_in,
                'check_out' :check_out,
                'no_of_guest':no_of_guest,
            }
            
            return render(request, 'room-available.html', context)
        else:
            room_type = request.POST['room_type']
            obj = Rooms.objects.all().exclude(room_type = room_type)
            context = {'rooms' : obj} 
            return render(request, 'rooms-other-available.html', context)
    else:
        obj = Rooms.objects.all()
        return render(request, 'rooms.html', {'rooms' : obj})


